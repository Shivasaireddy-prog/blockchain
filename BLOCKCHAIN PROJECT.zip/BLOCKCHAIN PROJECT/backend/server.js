const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Serve static frontend files from your 'frontend' folder
app.use(express.static(path.join(__dirname, '../frontend')));

// Explicitly serve index.html from 'frontend' on root GET request
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

let bookings = [];
let blocks = [
    { blockNumber: 1849201, hash: '0x8f4c2e1b...9a1', txCount: 4, gasUsed: '21,400' },
    { blockNumber: 1849200, hash: '0x3d2a1f9e...4b2', txCount: 12, gasUsed: '84,150' }
];

const mockBuses = [
    { id: 1, name: 'Speedy Deluxe', origin: 'Delhi', destination: 'Mumbai', type: 'AC Sleeper', price: 2075, departure: '8:00 PM' },
    { id: 2, name: 'SafeJourney Express', origin: 'Delhi', destination: 'Mumbai', type: 'Non-AC Seater', price: 1494, departure: '9:30 PM' },
    { id: 3, name: 'Silicon Link', origin: 'Hyderabad', destination: 'Bangalore', type: 'AC Sleeper', price: 1300, departure: '9:00 PM' }
];

app.get('/api/buses', (req, res) => {
    const { origin, destination } = req.query;
    if (origin && destination) {
        const filtered = mockBuses.filter(b => 
            b.origin.toLowerCase() === origin.toLowerCase() && 
            b.destination.toLowerCase() === destination.toLowerCase()
        );
        return res.json(filtered.length ? filtered : mockBuses);
    }
    res.json(mockBuses);
});

app.post('/api/book', (req, res) => {
    const { busId, wallet, passenger, amount } = req.body;
    const bus = mockBuses.find(b => b.id === busId);
    if (!bus) return res.status(404).json({ success: false, error: 'Bus not found' });

    const newBooking = {
        id: Date.now(),
        busId,
        busName: bus.name,
        origin: bus.origin,
        destination: bus.destination,
        wallet,
        passenger,
        amount,
        status: 'Confirmed',
        nftTokenId: Math.floor(1000 + Math.random() * 9000),
        txHash: '0x' + Array.from({length: 64}, () => Math.floor(Math.random()*16).toString(16)).join('')
    };

    bookings.push(newBooking);

    blocks.unshift({
        blockNumber: blocks[0].blockNumber + 1,
        hash: '0x' + Array.from({length: 40}, () => Math.floor(Math.random()*16).toString(16)).join(''),
        txCount: 1,
        gasUsed: '45,200'
    });

    res.json({ success: true, booking: newBooking });
});

app.get('/api/bookings', (req, res) => {
    const { wallet } = req.query;
    if (!wallet) return res.json(bookings);
    const userBookings = bookings.filter(b => b.wallet.toLowerCase() === wallet.toLowerCase());
    res.json(userBookings);
});

app.post('/api/cancel/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const booking = bookings.find(b => b.id === id);
    if (!booking) return res.status(404).json({ success: false, error: 'Booking not found' });

    booking.status = 'Cancelled & Refunded';
    res.json({ success: true, message: 'Escrow released and instant refund issued to wallet.' });
});

app.get('/api/chain/blocks', (req, res) => {
    res.json(blocks);
});

app.listen(PORT, () => {
    console.log(`🚀 AI Bus Agent Blockchain Backend running on http://localhost:${PORT}`);
});