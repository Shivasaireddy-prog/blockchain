// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract BusBookingEscrow {
    struct Ticket {
        uint256 id;
        address passenger;
        uint256 amount;
        bool isConfirmed;
        bool isRefunded;
    }

    mapping(uint256 => Ticket) public tickets;
    uint256 public ticketCounter;
    address public owner;

    event TicketBooked(uint256 indexed ticketId, address indexed passenger, uint256 amount);
    event RefundIssued(uint256 indexed ticketId, address indexed passenger, uint256 amount);

    constructor() {
        owner = msg.sender;
    }

    function bookTicket(uint256 id) external payable {
        require(msg.value > 0, "Must send bus fare");
        tickets[id] = Ticket({
            id: id,
            passenger: msg.sender,
            amount: msg.value,
            isConfirmed: true,
            isRefunded: false
        });
        emit TicketBooked(id, msg.sender, msg.value);
    }

    function cancelAndRefund(uint256 id) external {
        Ticket storage ticket = tickets[id];
        require(msg.sender == ticket.passenger || msg.sender == owner, "Unauthorized");
        require(ticket.isConfirmed, "Ticket not confirmed");
        require(!ticket.isRefunded, "Already refunded");

        ticket.isConfirmed = false;
        ticket.isRefunded = true;

        payable(ticket.passenger).transfer(ticket.amount);
        emit RefundIssued(id, ticket.passenger, ticket.amount);
    }
}